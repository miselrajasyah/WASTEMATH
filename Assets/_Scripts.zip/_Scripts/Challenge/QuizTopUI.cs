using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class QuizTopUI : MonoBehaviour
{
    public TMP_Text Category;
    public TMP_Text Difiiculty;
    public TMP_Text QuestionNo;
    public TMP_Text Score;
    public TMP_Text Timer;
    public Slider TimerSlider;
    public TMP_Text Question;
    

}
