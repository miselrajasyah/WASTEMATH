using UnityEngine;
[System.Serializable]
public class LengthQuestionClass
{
    [Header("Game Objects")]
    public GameObject[] LongObjects;
    public GameObject[] ShortObjects;


}
