using UnityEngine;
public class LongObjectClass : MonoBehaviour
{
    public int[] ShortEstimate;
}
