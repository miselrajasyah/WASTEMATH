using UnityEngine;

public class ObjectInfo : MonoBehaviour
{
    public string ObjectName;
    public AudioClip ObjAudioClip;
}
