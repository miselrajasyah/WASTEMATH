using UnityEngine;
public class BigObjectClass : MonoBehaviour
{
    public int[] smallEstimate;
    
}
