using UnityEngine;
public class LabelScriptClass : MonoBehaviour
{
    public string objLabel;
    public AudioClip ObjAudioClip;
}