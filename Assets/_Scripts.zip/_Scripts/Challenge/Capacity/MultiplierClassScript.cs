using UnityEngine;
public class MultiplierClassScript : MonoBehaviour
{
    public int[] multiplier;
}