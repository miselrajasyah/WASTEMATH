using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ItemWeight : MonoBehaviour
{
    public int weight;
    public AudioClip ObjAudioClip;
}
