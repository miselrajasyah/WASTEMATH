using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class HeavyObjectClass : MonoBehaviour
{
    public int[] lightEstimates;
    public AudioClip ObjAudioClip;
}
