using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class QuizData : MonoBehaviour
{
    public static string CATEGORY; 
    public static string DIFFICULTY; 
}
